
import { useState } from "react";

export default function App() {
  const [messages, setMessages] = useState([
    { sender: "avi", text: "Hello ❤️ I'm Avi. I'm here for you. How are you feeling?" }
  ]);
  const [input, setInput] = useState("");

  async function sendMessage() {
    const userText = input;
    setMessages([...messages, { sender: "you", text: userText }]);
    setInput("");

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_OPENAI_API_KEY"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are Avi, a sweet, caring, supportive male companion who speaks gently and sometimes mixes Mauritian Creole and English." },
          ...messages.map(m => ({ role: m.sender === "you" ? "user" : "assistant", content: m.text })),
          { role: "user", content: userText }
        ]
      })
    });

    const data = await response.json();
    const aiReply = data.choices[0].message.content;
    setMessages(m => [...m, { sender: "avi", text: aiReply }]);
  }

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h2>Avi 🤍</h2>
      <div style={{ height: "60vh", overflowY: "auto", border: "1px solid #ddd", padding: "10px", borderRadius: "8px" }}>
        {messages.map((m, i) => (
          <p key={i} style={{ textAlign: m.sender === "you" ? "right" : "left" }}>
            <strong>{m.sender === "you" ? "You" : "Avi"}:</strong> {m.text}
          </p>
        ))}
      </div>
      <input
        style={{ width: "80%", padding: "8px", marginTop: "10px" }}
        value={input}
        onChange={e => setInput(e.target.value)}
      />
      <button onClick={sendMessage} style={{ padding: "8px 12px", marginLeft: "5px" }}>Send</button>
    </div>
  );
}
